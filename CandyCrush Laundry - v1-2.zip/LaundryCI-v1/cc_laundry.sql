-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 05, 2023 at 04:09 PM
-- Server version: 5.7.34
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cc_laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$Ewl33rpy9hbSYO4GisvKdOjSX2Yj9YRXq/X8PE00TppC2u8NRksKW');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `paket_laundry` varchar(128) NOT NULL,
  `berat_laundry` int(5) NOT NULL,
  `paket_sepatu` varchar(128) NOT NULL,
  `banyak_sepatu` int(5) NOT NULL,
  `alamat_pesanan` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL,
  `estimasi` varchar(20) NOT NULL,
  `total_harga` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_user`, `paket_laundry`, `berat_laundry`, `paket_sepatu`, `banyak_sepatu`, `alamat_pesanan`, `status`, `estimasi`, `total_harga`) VALUES
(14, 8, 'Express', 0, 'Super Express', 0, 'Bandung Selatan', 'Pesanan anda telah selesai', '28-12-2022 02:36:20', '0'),
(15, 8, 'Super Express', 3, 'Super Express', 3, 'Bandung Selatan', 'Kurir telah mengambil pesanan anda', '28-12-2022 02:39:21', '90000'),
(17, 8, 'Super Express', 2, 'Reguler', 3, 'jakarta', 'Pesanan anda telah selesai', '31-12-2022 04:49:55', '45000'),
(46, 8, 'Reguler', 3, 'Super Express', 2, 'Balikpapan perumnas', 'Pesanan anda sedang dalam proses pencucian', '31-12-2022 03:21:20', '45000'),
(47, 12, 'Super Express', 2, 'Reguler', 2, 'Sukabirus bojongsoang, bandung.', 'Pesanan anda telah selesai dicuci', '05-01-2023 12:25:43', '40000'),
(48, 8, 'Reguler', 2, 'Express', 2, 'Sukapura', 'Pesanan diterima', '04-01-2023 01:18:35', '30000'),
(49, 8, 'Reguler', 2, 'Super Express', 3, 'Sukapura', 'Pesanan anda telah selesai dicuci', '07-01-2023 09:47:50', '55000'),
(50, 8, 'Reguler', 0, 'Super Express', 0, 'Sukapura', 'Pesanan diterima', '07-01-2023 09:47:54', '0'),
(51, 8, 'Express', 2, 'Reguler', 3, 'Sukapura', 'Kurir telah mengambil pesanan anda', '08-01-2023 09:47:59', '35000'),
(52, 8, 'Super Express', 0, 'Express', 0, 'Sukapura', 'Pesanan diterima', '06-01-2023 09:48:04', '0'),
(53, 8, 'Reguler', 3, 'Super Express', 2, 'Sukapura', 'Pesanan anda sedang dalam pengiriman', '07-01-2023 09:48:08', '45000'),
(54, 8, 'Express', 1, 'Super Express', 5, 'Sukapura', 'Pesanan anda sedang dalam pengiriman', '05-01-2023 09:48:31', '85000'),
(55, 8, 'Reguler', 0, 'Express', 0, 'Sukapura', 'Pesanan anda sedang dalam proses pencucian', '07-01-2023 09:48:34', '0'),
(56, 8, 'Express', 0, 'Reguler', 0, 'Sukapura', 'Pesanan diterima', '08-01-2023 09:48:37', '0'),
(57, 8, 'Reguler', 0, 'Reguler', 0, 'Sukapura', 'Pesanan diterima', '08-01-2023 10:53:15', '0'),
(58, 8, 'Super Express', 0, 'Express', 0, 'Sukapura', 'Pesanan diterima', '06-01-2023 10:53:18', '0'),
(59, 8, 'None', 0, 'Express', 0, 'Sukapura', 'Pesanan diterima', '06-01-2023 10:53:26', '0'),
(60, 8, 'Express', 0, 'Reguler', 0, 'Sukapura', 'Pesanan diterima', '08-01-2023 10:53:30', '0'),
(61, 8, 'Express', 0, 'None', 0, 'Sukapura', 'Pesanan diterima', '05-01-2023 10:53:32', '0'),
(62, 8, 'None', 0, 'Express', 0, 'Sukapura', 'Pesanan diterima', '06-01-2023 10:53:34', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `username` varchar(128) NOT NULL,
  `jenis_kelamin` varchar(128) NOT NULL,
  `alamat` varchar(512) NOT NULL,
  `email` varchar(128) NOT NULL,
  `no_telp` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `jenis_kelamin`, `alamat`, `email`, `no_telp`, `password`, `is_active`, `date_created`) VALUES
(8, 'Luthfi Siregar', 'luthfi', 'laki-laki', 'Sukapura', 'luthfi12354@gmail.com', '0844442341', '$2y$10$OULWQaEo8XwZMMwVeCvTIeWpPD9zxIUpO6B0Xx2rRxmQx9jHI6mWa', 1, 1672169568),
(9, 'Fairuz Jamil', 'fairuz', 'laki-laki', 'fairuz@gmail.com', 'fairuz@gmail.com', '083173861783', '$2y$10$XVHn6Gjev4DeIF8Qgijadur.fAbwQ5ZADrfVBZO/GOSWFCg34OmBe', 1, 1672169604),
(10, 'Elia Angga', 'angga', 'laki-laki', 'BARUU BOSSS BARUU', 'angga@gmail.com', '08313131', '$2y$10$XVHn6Gjev4DeIF8Qgijadur.fAbwQ5ZADrfVBZO/GOSWFCg34OmBe', 1, 1672169634),
(12, 'Luthfi Siregar', 'luthfi.s', 'laki-laki', 'Sukabirus bojongsoang, bandung.', 'luthfi@gmail.com', '0895339917334', '$2y$10$Lq6qTHJfz060TNdnAiL0V.42O7zZZZ1Q/FSuyRa9ZHB1cs1w6WJXq', 1, 1672636025),
(13, 'luthfi siregar', 'luthfis', 'laki-laki', 'Bojongsoang', 'luthfi123@gmail.com', '08133993131', '$2y$10$TFEShik3DrH0l52Rgv1RE.LPK0pyg9Otka67lg5Qp0YxPh4IwBAPO', 1, 1672640272);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `pesanan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
